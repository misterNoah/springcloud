package com.springcloud.microservicesimpleproviceuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSimpleProviceUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSimpleProviceUserApplication.class, args);
	}
}
