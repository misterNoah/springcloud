package com.springcloud.microservicesimplecusormermovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSimpleCusormerMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSimpleCusormerMovieApplication.class, args);
	}
}
